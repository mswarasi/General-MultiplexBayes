
###########################################

## Reproducing Table 4

opt.psz <- readRDS( "./data_analysis/intermediate_results/Table_4.rds" )

S <- 3
se.urine <- cbind( rep(0.947, S), rep(0.913, S) )
sp.urine <- cbind( rep(0.989, S), rep(0.993, S) )

se.swab <- cbind( rep(0.942, S), rep(0.992, S) )
sp.swab <- cbind( rep(0.976, S), rep(0.987, S) )

Table.4 <- cbind(
  c("Urine", "", "", "", "Swab", "", ""),
  c("H2", "H3", "AT", "", "H2", "H3", "AT"),
  c(opt.psz[1,1,1], opt.psz[2,1,1], opt.psz[3,1,1], "", 
    opt.psz[1,1,2], opt.psz[2,1,2], opt.psz[3,1,2]),	
  c(opt.psz[1,2,1], opt.psz[2,2,1], opt.psz[3,2,1], "", 
    opt.psz[1,2,2], opt.psz[2,2,2], opt.psz[3,2,2]),
  c(opt.psz[1,3,1], opt.psz[2,3,1], opt.psz[3,3,1], "", 
    opt.psz[1,3,2], opt.psz[2,3,2], opt.psz[3,3,2]),	
  c("", "", "", "", "", "", ""),
#  c("Urine", "", "", "", "Swab", "", ""),
  c("CT", "NG", "", "", "CT", "NG", ""),
  c( paste("Se:(1)1=", se.urine[1, 1], sep=""),  
  paste("Se:(1)2=", se.urine[1, 2], sep=""), "",
  "", paste("Se:(1)1=", se.swab[1, 1], sep=""),  
  paste("Se:(1)2=", se.swab[1, 2], sep=""), "" ),
  c( paste("Sp:(1)1=", sp.urine[1, 1], sep=""),  
  paste("Sp:(1)2=", sp.urine[1, 2], sep=""), "",
  "", paste("Sp:(1)1=", sp.swab[1, 1], sep=""),  
  paste("Sp:(1)2=", sp.swab[1, 2], sep=""), "" )
)

Table.4[ is.na(Table.4) ] <- ""
Table_4 <- as.data.frame( Table.4 )
colnames( Table_4 ) <- c( "", "Protocol", "Pool sizes", "", "", "", "", "Sensitivity", "Specificity" )

## Table 4
Table_4


###########################################

## Reproducing Tables 5-6

Table <- "5_6"

options( scipen = 999 )
Table.5 <- matrix(NA, nrow = 25, ncol = 8)
Table.6 <- matrix(NA, nrow = 19, ncol = 8)

for( stratum in c( "urine", "swab" ) ){

if( stratum == "urine" ){
  i1 <- 0
  i2 <- 0
}

if( stratum == "swab" ){
  i1 <- 13
  i2 <- 10
}

## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./data_analysis/intermediate_results/", "Table_", Table, "_stratum-", stratum, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
delta.Mean <- res_h2$delta.Mean
delta.SE <- res_h2$delta.SE
p.MAP <- res_h2$p.MAP
delta.MAP <- res_h2$delta.MAP
T <- res_h2$T

## Mean Estimation:
Table.5[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.5[i1+1:4, 2] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+1:4, 1] <- round(colMeans(delta.Mean), 3)   # Est
Table.6[i2+1:4, 2] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.5[i1+6:9, 1] <- round(colMeans(p.MAP), 3)    # Est
Table.5[i1+6:9, 2] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+6:9, 1] <- round(colMeans(delta.MAP), 3)    # Est
Table.6[i2+6:9, 2] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.5[i1+11, 1] <- round( mean(T), 1 )    
Table.5[i1+12, 1] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./data_analysis/intermediate_results/", "Table_", Table, "_stratum-", stratum, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
delta.Mean <- res_h3$delta.Mean
delta.SE <- res_h3$delta.SE
p.MAP <- res_h3$p.MAP
delta.MAP <- res_h3$delta.MAP
T <- res_h3$T


## Mean Estimation:
Table.5[i1+1:4, 4] <- round(colMeans(p.Mean), 3)   # Est
Table.5[i1+1:4, 5] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+1:4, 4] <- round(colMeans(delta.Mean), 3)   # Est
Table.6[i2+1:4, 5] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.5[i1+6:9, 4] <- round(colMeans(p.MAP), 3)    # Est
Table.5[i1+6:9, 5] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+6:9, 4] <- round(colMeans(delta.MAP), 3)    # Est
Table.6[i2+6:9, 5] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.5[i1+11, 4] <- round( mean(T), 1 )    
Table.5[i1+12, 4] <- round( sd(T), 1 )


## AT
Protocol <- "AT"
res_at <- readRDS( paste("./data_analysis/intermediate_results/", "Table_", Table, "_stratum-", stratum, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
delta.Mean <- res_at$delta.Mean
delta.SE <- res_at$delta.SE
p.MAP <- res_at$p.MAP
delta.MAP <- res_at$delta.MAP
T <- res_at$T

## Mean Estimation:
Table.5[i1+1:4, 7] <- round(colMeans(p.Mean), 3)   # Est
Table.5[i1+1:4, 8] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+1:4, 7] <- round(colMeans(delta.Mean), 3)   # Est
Table.6[i2+1:4, 8] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.5[i1+6:9, 7] <- round(colMeans(p.MAP), 3)    # Est
Table.5[i1+6:9, 8] <- round(colMeans(p.SE), 4)     # SE

Table.6[i2+6:9, 7] <- round(colMeans(delta.MAP), 3)    # Est
Table.6[i2+6:9, 8] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.5[i1+11, 7] <- round( mean(T), 1 )    
Table.5[i1+12, 7] <- round( sd(T), 1 )

}

## Preparing Table 5
dfr1 <- data.frame( cbind(
     c("","","","","Urine","N=4402","","","","","","", 
	   "",  "","","","","Swab","N=10048","","","","","",""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T"),
     c("-", "+", "-", "+", "", "-", "+", "-", "+", "", "", "", "", 
       "-", "+", "-", "+", "", "-", "+", "-", "+", "", "", ""),
     c("-", "-", "+", "+", "", "-", "-", "+", "+", "", "", "", "", 
       "-", "-", "+", "+", "", "-", "-", "+", "+", "", "", "")
	   ))

dfr1 <- data.frame( dfr1, Table.5 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_5 <- as.data.frame(dfr1)

## Mean
T <- as.numeric( c( Table_5[11, 5], Table_5[11, 8], Table_5[11, 11] ) )
redc <- round( 100*(T[1] - T[-1])/T[1], 1 )
T.redc <- c( T[1],
             paste( T[2], "(", redc[1], "%", ")", sep="" ),
             paste( T[3], "(", redc[2], "%", ")", sep="" )
            )
Table_5[11, 8] <- T.redc[2]
Table_5[11, 11] <- T.redc[3]

## MAP
T <- as.numeric( c( Table_5[24, 5], Table_5[24, 8], Table_5[24, 11] ) )
redc <- round( 100*(T[1] - T[-1])/T[1], 1 )
T.redc <- c( T[1],
             paste( T[2], "(", redc[1], "%", ")", sep="" ),
             paste( T[3], "(", redc[2], "%", ")", sep="" )
            )
Table_5[24, 8] <- T.redc[2]
Table_5[24, 11] <- T.redc[3]
colnames( Table_5 ) <- c("Stratum", "", "CT", "NG", "Est", "SE", "", "Est", "SE", "", "Est", "SE")

## Table 5
protocols <- paste("                          H2                 H3                  AT")
cline <-     paste("                   ============    ===================   ===================")

noquote(protocols); noquote(cline); Table_5

               				   
## Preparing Table 6
dfr2 <- data.frame( cbind(
     c("","","","","Urine","N=4402","","","","","","", 
	   "","","Swab","N=10048","","",""),
     c("", "", "", "Se:(1)1=0.947", "Se:(1)2=0.913", "Sp:(1)1=0.989", "Sp:(1)2=0.993", "", "", "",  
	   "", "", "", "Se:(1)1=0.942", "Se:(1)2=0.992", "Sp:(1)1=0.976", "Sp:(1)2=0.987", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "",  
	   "Mean", "", "", "", "", "MAP", "", "", "")))

dfr2 <- data.frame( dfr2, Table.6 )
dfr2 <- sapply(dfr2, as.character)
dfr2[is.na(dfr2)] <- " "

Table_6 <- as.data.frame(dfr2)
colnames( Table_6 ) <- c("Stratum", "Accuracy", "", "Est", "SE", "", "Est", "SE", "", "Est", "SE")
        
		
## Table 6
protocols <- paste("                               H2            H3            AT")
cline <-     paste("                         ============   ===========   ===========")

noquote(protocols); noquote(cline); Table_6

		  