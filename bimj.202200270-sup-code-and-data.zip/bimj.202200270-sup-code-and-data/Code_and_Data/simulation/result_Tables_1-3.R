
#################################################

## Reproducing Table 1:

opt.psz <- readRDS("./simulation/intermediate_results/Table_1.rds")

Table_1 <- data.frame( c("H2", "H3", "H4", "AT"), opt.psz[ , ,1], 
                       c("", "", "", ""), 
                       c("H2", "H3", "H4", "AT"), opt.psz[ , ,2])
colnames( Table_1 ) <- c("Protocol", "Pool sizes", "", "", "", "", "Protocol", "Pool sizes", "", "", "")
Table_1[ is.na(Table_1) ] <- ""


config <- paste("   Configuration I            Configuration II   ")
cline <- paste("=========================  ==========================")
noquote(config); noquote(cline); Table_1


#################################################

## Reproducing Tables 2-3:

options( scipen = 999 )
Table.2 <- matrix(NA, nrow = 25, ncol = 15)
Table.3 <- matrix(NA, nrow = 19, ncol = 15)

for(Configuration in c("I", "II")){

if(Configuration == "I"){
  i1 <- 0
  i2 <- 0
}

if(Configuration == "II"){
  i1 <- 13
  i2 <- 10
}

## H2

res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", "2-3", "_Protocol-", "H2", "_config-", Configuration, ".rds", sep="") )
p.Mean <- res_h2$p.Mean
p.SE   <- res_h2$p.SE
delta.Mean <- res_h2$delta.Mean
delta.SE   <- res_h2$delta.SE
p.MAP <- res_h2$p.MAP
delta.MAP <- res_h2$delta.MAP
T <- res_h2$T

## Mean Estimation:
Table.2[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.2[i1+1:4, 2] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.2[i1+1:4, 3] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+1:4, 1] <- round(colMeans(delta.Mean), 3)   # Est
Table.3[i2+1:4, 2] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.3[i2+1:4, 3] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.2[i1+6:9, 1] <- round(colMeans(p.MAP), 3)    # Est
Table.2[i1+6:9, 2] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.2[i1+6:9, 3] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+6:9, 1] <- round(colMeans(delta.MAP), 3)    # Est
Table.3[i2+6:9, 2] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.3[i2+6:9, 3] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.2[i1+11, 1] <- round( mean(T), 1 )    
Table.2[i1+12, 1] <- round( sd(T), 1 )


## H3

res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", "2-3", "_Protocol-", "H3", "_config-", Configuration, ".rds", sep="") )
p.Mean <- res_h3$p.Mean
p.SE   <- res_h3$p.SE
delta.Mean <- res_h3$delta.Mean
delta.SE   <- res_h3$delta.SE
p.MAP <- res_h3$p.MAP
delta.MAP <- res_h3$delta.MAP
T <- res_h3$T

## Mean Estimation:
Table.2[i1+1:4, 5] <- round(colMeans(p.Mean), 3)   # Est
Table.2[i1+1:4, 6] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.2[i1+1:4, 7] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+1:4, 5] <- round(colMeans(delta.Mean), 3)   # Est
Table.3[i2+1:4, 6] <- round(apply(delta.Mean,2, sd), 3) # SD
Table.3[i2+1:4, 7] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.2[i1+6:9, 5] <- round(colMeans(p.MAP), 3)    # Est
Table.2[i1+6:9, 6] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.2[i1+6:9, 7] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+6:9, 5] <- round(colMeans(delta.MAP), 3)    # Est
Table.3[i2+6:9, 6] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.3[i2+6:9, 7] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.2[i1+11, 5] <- round( mean(T), 1 )    
Table.2[i1+12, 5] <- round( sd(T), 1 )


## H4

res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", "2-3", "_Protocol-", "H4", "_config-", Configuration, ".rds", sep="") )
p.Mean <- res_h4$p.Mean
p.SE   <- res_h4$p.SE
delta.Mean <- res_h4$delta.Mean
delta.SE   <- res_h4$delta.SE
p.MAP <- res_h4$p.MAP
delta.MAP <- res_h4$delta.MAP
T <- res_h4$T

## Mean Estimation:
Table.2[i1+1:4, 9] <- round(colMeans(p.Mean), 3)   # Est
Table.2[i1+1:4, 10] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.2[i1+1:4, 11] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+1:4, 9] <- round(colMeans(delta.Mean), 3)   # Est
Table.3[i2+1:4, 10] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.3[i2+1:4, 11] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.2[i1+6:9, 9] <- round(colMeans(p.MAP), 3)    # Est
Table.2[i1+6:9, 10] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.2[i1+6:9, 11] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+6:9, 9] <- round(colMeans(delta.MAP), 3)    # Est
Table.3[i2+6:9, 10] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.3[i2+6:9, 11] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.2[i1+11, 9] <- round( mean(T), 1 )    
Table.2[i1+12, 9] <- round( sd(T), 1 )

## AT

res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", "2-3", "_Protocol-", "AT", "_config-", Configuration, ".rds", sep="") )
p.Mean <- res_at$p.Mean
p.SE   <- res_at$p.SE
delta.Mean <- res_at$delta.Mean
delta.SE   <- res_at$delta.SE
p.MAP <- res_at$p.MAP
delta.MAP <- res_at$delta.MAP
T <- res_at$T

## Mean Estimation:
Table.2[i1+1:4, 13] <- round(colMeans(p.Mean), 3)   # Est
Table.2[i1+1:4, 14] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.2[i1+1:4, 15] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+1:4, 13] <- round(colMeans(delta.Mean), 3)   # Est
Table.3[i2+1:4, 14] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.3[i2+1:4, 15] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.2[i1+6:9, 13] <- round(colMeans(p.MAP), 3)    # Est
Table.2[i1+6:9, 14] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.2[i1+6:9, 15] <- round(colMeans(p.SE), 4)     # SE

Table.3[i2+6:9, 13] <- round(colMeans(delta.MAP), 3)    # Est
Table.3[i2+6:9, 14] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.3[i2+6:9, 15] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.2[i1+11, 13] <- round( mean(T), 1 )    
Table.2[i1+12, 13] <- round( sd(T), 1 )
}

dfr1 <- data.frame( cbind(
     c("","","","","","Config-I","","","","","","", 
	   "",  "","","","","","Config-II","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.990", "p10=0.004", "p01=0.004", "p11=0.002", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.2 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_2 <- as.data.frame(dfr1)
colnames( Table_2 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")				   

## Mean
T <- as.numeric( c( Table_2[11, 4], Table_2[11, 8], Table_2[11, 12], Table_2[11, 16] ) )
redc <- round( 100*(T[1] - T[-1])/T[1], 1 )
T.redc <- c( T[1],
             paste( T[2], "(", redc[1], "%", ")", sep="" ),
             paste( T[3], "(", redc[2], "%", ")", sep="" ),
             paste( T[4], "(", redc[3], "%", ")", sep="" )
            )
Table_2[11, 8] <- T.redc[2]
Table_2[11, 12] <- T.redc[3]
Table_2[11, 16] <- T.redc[4]

## MAP
T <- as.numeric( c( Table_2[24, 4], Table_2[24, 8], Table_2[24, 12], Table_2[24, 16] ) )
redc <- round( 100*(T[1] - T[-1])/T[1], 1 )
T.redc <- c( T[1],
             paste( T[2], "(", redc[1], "%", ")", sep="" ),
             paste( T[3], "(", redc[2], "%", ")", sep="" ),
             paste( T[4], "(", redc[3], "%", ")", sep="" )
            )
Table_2[24, 8] <- T.redc[2]
Table_2[24, 12] <- T.redc[3]
Table_2[24, 16] <- T.redc[4]



dfr2 <- data.frame( cbind(
     c("","","","","","Config-I","","","","","","", 
	   "","","","Config-II","","",""),
     c("", "", "", "Se:(1)1=0.95", "Se:(1)2=0.95", "Sp:(1)1=0.99", "Sp:(1)2=0.99", "", "", "",  
	   "", "", "", "Se:(1)1=0.95", "Se:(1)2=0.95", "Sp:(1)1=0.99", "Sp:(1)2=0.99", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "",  
	   "Mean", "", "", "", "", "MAP", "", "", "")))

dfr2 <- data.frame( dfr2, Table.3 )
dfr2 <- sapply(dfr2, as.character)
dfr2[is.na(dfr2)] <- " "

Table_3 <- as.data.frame(dfr2)
colnames( Table_3 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")

## Table 2
protocols <- paste("                                  H2                       H3                           H4                         AT")
cline <-     paste("                         ===================    =========================   ==========================   ===========================")

noquote(protocols); noquote(cline); Table_2


## Table 3	   
protocols <- paste("                                   H2                  H3                  H4                  AT")
cline <-     paste("                           =================   =================   ==================   =================")

noquote(protocols); noquote(cline); Table_3

