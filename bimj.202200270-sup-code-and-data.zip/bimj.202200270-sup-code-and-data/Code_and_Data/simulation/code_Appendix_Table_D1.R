
##################################################

# 'ncores' is the number of cores to be used
# for parallel computing in Windows with 64-bit R:
ncores <- 10

# 'nsims' is the number of simulated data sets:
nsims <- 500

## Importing source code & loading packages:
library(MCMCpack)
library("parallel")

source("./source_code/MainFunctions.R")
source("./source_code/SupportPrograms.R")
source("./source_code/GT_sim_fns.R")

# Making clusters for parallel computing:
cl <- makeCluster(ncores)
clusterExport(cl, "hier.alg.data")
clusterExport(cl, "array.2dim.data")
clusterExport(cl, "PostUnknownAssayAcr")
clusterExport(cl, "poolMembTracker")
clusterExport(cl, "EmUnknownAssayAcr")
clusterExport(cl, "EmultGibbs2")
clusterExport(cl, "PostKnownAssayAcr")
clusterExport(cl, "EmKnownAssayAcr")
clusterExport(cl, "EmultGibbs")

##################################################

## The code below reproduces the simulation results 
## depicted in Table D.1 of the Supporting Information.
## The accuracy parameter 'delta' is assumed to be known.

Table <- "D1"

# Setting seed:
RNGkind(kind = "L'Ecuyer-CMRG")
set.seed(123)
clusterSetRNGStream(cl = cl, iseed = 123)

# Simulation parameters:
N <- 5000         # Sample size
Se <- c(.95,.95)  # True sensitivities for diseases 1 & 2
Sp <- c(.99,.99)  # True specificities for diseases 1 & 2

## Specify the prior hyperparameters as shown below. 
## Flat priors have been used for all parameters.
p.pr <- rep(1,4)
Se1.pr <- c(1,1)
Se2.pr <- c(1,1)
Sp1.pr <- c(1,1)
Sp2.pr <- c(1,1)

G <- 12000               # number of Gibbs iterates
burn <- 2000             # burn-in period
pick <- seq(1,10000,5)   # keeping every 5th

## Convergence tolerance for the EM algorithm
epsilon <- 0.001

## Maximum number of iterations for the EM algorithm. 
emmaxit <- 200

## Choose an initial value of the parameter p. The initial value 
## can be specified from historical, pilot study, or any contextual 
## estimate. We use p0 <- c(.92,.05,.02,.01) throughout the paper.
p0 <- c(.92,.05,.02,.01)

options( scipen = 999 )

for(Configuration in c("I", "II")){

if(Configuration == "I"){
  ## Configuration I
  p <- c(.95,.02,.02,.01)     # True value of p
  MPT <- 5
  H2 <- c(5,1)
  H3 <- c(9,3,1)
  H4 <- c(18,6,3,1)
  AT <- c(11,11,1)  # For AT, c(11,11,1), not c(11,11)
                    # because tests are done in 3 stages:
                    # row pool, col pool, & individual testing
}

if(Configuration == "II"){
  ## Configuration II
  p <- c(.990,.004,.004,.002) # True value of p
  MPT <- 11
  H2 <- c(11,1)
  H3 <- c(25,5,1)
  H4 <- c(48,12,4,1)
  AT <- c(29,29,1)
}

#========= Estimation with MPT protocol =========#

protocol <- MPT
list.zmat <- lapply( rep(N, nsims), hier.alg.data, p=p,
                     design=protocol, Se=Se, Sp=Sp )

## POSTERIOR SAMPLING 
res.bayes <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           postGit=G, method="Bayes", accuracy="known")

## MAP ESTIMATION
res.map <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           emGit=G, emburn=burn, method="MAP", accuracy="known")


p.Mean <- p.MAP <- p.SE <- matrix(-9, nsims, 4)
T <- rep(-9, nsims)

for(s in 1:nsims){
## POSTERIOR SAMPLING 
  res1 <- res.bayes[[s]]
  p.Mean[s, ] <- colMeans(res1$prevalence[-(1:burn), ][pick, ])
  p.SE[s, ] <- apply(res1$prevalence[-(1:burn), ][pick, ], 2, sd)

## MAP ESTIMATION
  res2 <- res.map[[s]]
  p.MAP[s, ] <- res2$prevalence

## Number of tests
  T[s] <- nrow( list.zmat[[s]] )
}

res_mpt <- list( "p.Mean" = p.Mean, "p.SE" = p.SE, 
                 "p.MAP" = p.MAP, "T" = T )

Protocol <- "MPT"
saveRDS( res_mpt, paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )


#========= Estimation with H2 protocol =========#

protocol <- H2
list.zmat <- lapply( rep(N, nsims), hier.alg.data, p=p,
                     design=protocol, Se=Se, Sp=Sp )
		   
## POSTERIOR SAMPLING 
res.bayes <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           postGit=G, method="Bayes", accuracy="known")

## MAP ESTIMATION
res.map <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           emGit=G, emburn=burn, method="MAP", accuracy="known")

p.Mean <- p.MAP <- p.SE <- matrix(-9, nsims, 4)
T <- rep(-9, nsims)

for(s in 1:nsims){
## POSTERIOR SAMPLING 
  res1 <- res.bayes[[s]]
  p.Mean[s, ] <- colMeans(res1$prevalence[-(1:burn), ][pick, ])
  p.SE[s, ] <- apply(res1$prevalence[-(1:burn), ][pick, ], 2, sd)

## MAP ESTIMATION
  res2 <- res.map[[s]]
  p.MAP[s, ] <- res2$prevalence

## Number of tests
  T[s] <- nrow( list.zmat[[s]] )
}

res_h2 <- list( "p.Mean" = p.Mean, "p.SE" = p.SE, 
                 "p.MAP" = p.MAP, "T" = T )				 

Protocol <- "H2"
saveRDS( res_h2, paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )


#========= Estimation with H3 protocol =========#

protocol <- H3
list.zmat <- lapply( rep(N, nsims), hier.alg.data, p=p,
                     design=protocol, Se=Se, Sp=Sp )

## POSTERIOR SAMPLING 
res.bayes <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           postGit=G, method="Bayes", accuracy="known")

## MAP ESTIMATION
res.map <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           emGit=G, emburn=burn, method="MAP", accuracy="known")

p.Mean <- p.MAP <- p.SE <- matrix(-9, nsims, 4)
T <- rep(-9, nsims)

for(s in 1:nsims){
## POSTERIOR SAMPLING 
  res1 <- res.bayes[[s]]
  p.Mean[s, ] <- colMeans(res1$prevalence[-(1:burn), ][pick, ])
  p.SE[s, ] <- apply(res1$prevalence[-(1:burn), ][pick, ], 2, sd)

## MAP ESTIMATION
  res2 <- res.map[[s]]
  p.MAP[s, ] <- res2$prevalence

## Number of tests
  T[s] <- nrow( list.zmat[[s]] )
}

res_h3 <- list( "p.Mean" = p.Mean, "p.SE" = p.SE, 
                 "p.MAP" = p.MAP, "T" = T )

Protocol <- "H3"
saveRDS( res_h3, paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

#========= Estimation with H4 protocol =========#

protocol <- H4
list.zmat <- lapply( rep(N, nsims), hier.alg.data, p=p,
                     design=protocol, Se=Se, Sp=Sp )

## POSTERIOR SAMPLING 
res.bayes <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           postGit=G, method="Bayes", accuracy="known")

## MAP ESTIMATION
res.map <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           emGit=G, emburn=burn, method="MAP", accuracy="known")

p.Mean <- p.MAP <- p.SE <- matrix(-9, nsims, 4)
T <- rep(-9, nsims)

for(s in 1:nsims){
## POSTERIOR SAMPLING 
  res1 <- res.bayes[[s]]
  p.Mean[s, ] <- colMeans(res1$prevalence[-(1:burn), ][pick, ])
  p.SE[s, ] <- apply(res1$prevalence[-(1:burn), ][pick, ], 2, sd)

## MAP ESTIMATION
  res2 <- res.map[[s]]
  p.MAP[s, ] <- res2$prevalence

## Number of tests
  T[s] <- nrow( list.zmat[[s]] )
}

res_h4 <- list( "p.Mean" = p.Mean, "p.SE" = p.SE, 
                 "p.MAP" = p.MAP, "T" = T )
			
Protocol <- "H4"			
saveRDS( res_h4, paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )


#========= Estimation with AT protocol =========#

protocol <- AT
list.zmat <- lapply( rep(N, nsims), array.2dim.data, p=p,
                     design=protocol, Se=Se, Sp=Sp )

## POSTERIOR SAMPLING 
res.bayes <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           postGit=G, method="Bayes", accuracy="known")

## MAP ESTIMATION
res.map <- parLapply(cl, list.zmat, mult.gt.bayes, 
           p0=p0, N=N, S=length(protocol), p.pr=p.pr,
           emGit=G, emburn=burn, method="MAP", accuracy="known")

p.Mean <- p.MAP <- p.SE <- matrix(-9, nsims, 4)
T <- rep(-9, nsims)

for(s in 1:nsims){
## POSTERIOR SAMPLING 
  res1 <- res.bayes[[s]]
  p.Mean[s, ] <- colMeans(res1$prevalence[-(1:burn), ][pick, ])
  p.SE[s, ] <- apply(res1$prevalence[-(1:burn), ][pick, ], 2, sd)

## MAP ESTIMATION
  res2 <- res.map[[s]]
  p.MAP[s, ] <- res2$prevalence

## Number of tests
  T[s] <- nrow( list.zmat[[s]] )
}

res_at <- list( "p.Mean" = p.Mean, "p.SE" = p.SE, 
                 "p.MAP" = p.MAP, "T" = T )

Protocol <- "AT"
saveRDS( res_at, paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )
				 
}

stopCluster( cl )

