
###########################################

## Reproducing Table D.1

Table <- "D1"
Table.D1 <- matrix(NA, nrow = 25, ncol = 19)

for(Configuration in c("I", "II")){

if(Configuration == "I"){
  i1 <- 0
  i2 <- 0
}

if(Configuration == "II"){
  i1 <- 13
  i2 <- 10
}

## MPT
Protocol <- "MPT"
res_mpt <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_mpt$p.Mean
p.SE <- res_mpt$p.SE
p.MAP <- res_mpt$p.MAP
T <- res_mpt$T

## Mean Estimation:
Table.D1[i1+1:4, 1] <- round(colMeans(p.Mean),3)   # Est
Table.D1[i1+1:4, 2] <- round(apply(p.Mean,2,sd),4) # SD
Table.D1[i1+1:4, 3] <- round(colMeans(p.SE),4)     # SE

## MAP Estimation:
Table.D1[i1+6:9, 1] <- round(colMeans(p.MAP),3)    # Est
Table.D1[i1+6:9, 2] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D1[i1+6:9, 3] <- round(colMeans(p.SE),4)     # SE

## Avg. number of tests:
Table.D1[i1+11, 2] <- round( mean(T), 1 )    
Table.D1[i1+12, 2] <- round( sd(T), 1 )


## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
p.MAP <- res_h2$p.MAP
T <- res_h2$T

## Mean Estimation:
Table.D1[i1+1:4, 5] <- round(colMeans(p.Mean),3)   # Est
Table.D1[i1+1:4, 6] <- round(apply(p.Mean,2,sd),4) # SD
Table.D1[i1+1:4, 7] <- round(colMeans(p.SE),4)     # SE

## MAP Estimation:
Table.D1[i1+6:9, 5] <- round(colMeans(p.MAP),3)    # Est
Table.D1[i1+6:9, 6] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D1[i1+6:9, 7] <- round(colMeans(p.SE),4)     # SE

## Avg. number of tests:
Table.D1[i1+11, 6] <- round( mean(T), 1 )    
Table.D1[i1+12, 6] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
p.MAP <- res_h3$p.MAP
T <- res_h3$T

## Mean Estimation:
Table.D1[i1+1:4, 9] <- round(colMeans(p.Mean),3)   # Est
Table.D1[i1+1:4, 10] <- round(apply(p.Mean,2,sd),4) # SD
Table.D1[i1+1:4, 11] <- round(colMeans(p.SE),4)     # SE

## MAP Estimation:
Table.D1[i1+6:9, 9] <- round(colMeans(p.MAP),3)    # Est
Table.D1[i1+6:9, 10] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D1[i1+6:9, 11] <- round(colMeans(p.SE),4)     # SE

## Avg. number of tests:
Table.D1[i1+11, 10] <- round( mean(T), 1 )    
Table.D1[i1+12, 10] <- round( sd(T), 1 )


## H4
Protocol <- "H4"
res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h4$p.Mean
p.SE <- res_h4$p.SE
p.MAP <- res_h4$p.MAP
T <- res_h4$T

## Mean Estimation:
Table.D1[i1+1:4, 13] <- round(colMeans(p.Mean),3)   # Est
Table.D1[i1+1:4, 14] <- round(apply(p.Mean,2,sd),4) # SD
Table.D1[i1+1:4, 15] <- round(colMeans(p.SE),4)     # SE

## MAP Estimation:
Table.D1[i1+6:9, 13] <- round(colMeans(p.MAP),3)    # Est
Table.D1[i1+6:9, 14] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D1[i1+6:9, 15] <- round(colMeans(p.SE),4)     # SE

## Avg. number of tests:
Table.D1[i1+11, 14] <- round( mean(T), 1 )    
Table.D1[i1+12, 14] <- round( sd(T), 1 )


## AT
Protocol <- "AT"
res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
p.MAP <- res_at$p.MAP
T <- res_at$T

## Mean Estimation:
Table.D1[i1+1:4, 17] <- round(colMeans(p.Mean),3)   # Est
Table.D1[i1+1:4, 18] <- round(apply(p.Mean,2,sd),4) # SD
Table.D1[i1+1:4, 19] <- round(colMeans(p.SE),4)     # SE

## MAP Estimation:
Table.D1[i1+6:9, 17] <- round(colMeans(p.MAP),3)    # Est
Table.D1[i1+6:9, 18] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D1[i1+6:9, 19] <- round(colMeans(p.SE),4)     # SE

## Avg. number of tests:
Table.D1[i1+11, 18] <- round( mean(T), 1 )    
Table.D1[i1+12, 18] <- round( sd(T), 1 )

}

## Preparing & saving Table D.1
dfr1 <- data.frame( cbind(
     c("","","","","","Config-I","","","","","","", 
	   "",  "","","","","","Config-II","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.990", "p10=0.004", "p01=0.004", "p11=0.002", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.D1 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_D1 <- as.data.frame(dfr1)
colnames( Table_D1 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                        "", "Est", "SD", "SE", "", "Est", "SD", "SE", "", "Est", "SD", "SE")


##============= Table D.1 =============##

protocols <- paste("                                 MPT                     H2                    H3                    H4                    AT")
cline <-     paste("                          ===================    ===================   ===================   ===================   ===================")

noquote(protocols); noquote(cline); Table_D1


###########################################

## Reproducing Table D.2

opt.psz <- readRDS( "./simulation/intermediate_results/Table_D2.rds" )

Table_D2 <- data.frame( c("H2", "H3", "H4", "AT"), opt.psz[ , ,1], 
                       c("","","",""), 
                       c("H2", "H3", "H4", "AT"), opt.psz[ , ,2])
colnames( Table_D2 ) <- c("Protocol", "Pool sizes", "", "", "", 
                          "", "Protocol", "Pool sizes", "", "", "")
Table_D2[ is.na(Table_D2) ] <- ""


##============= Table D.2 =============##

config <- paste("   Configuration I            Configuration II   ")
cline <- paste("=========================  ==========================")

noquote(config); noquote(cline); Table_D2


###########################################

## Reproducing Tables D.3-D.5

Table <- "D3_D5"
Table.D3 <- matrix(NA, nrow = 25, ncol = 15)
Table.D4 <- matrix(NA, nrow = 17, ncol = 15)
Table.D5 <- matrix(NA, nrow = 17, ncol = 15)

for(Configuration in c("I", "II")){

if(Configuration == "I"){
  ## Configuration I
  i1 <- 0
  i2 <- 0
}

if(Configuration == "II"){
  ## Configuration II
  i1 <- 13
  i2 <- 10
}

## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
delta.Mean <- res_h2$delta.Mean
delta.SE <- res_h2$delta.SE
p.MAP <- res_h2$p.MAP
delta.MAP <- res_h2$delta.MAP
T <- res_h2$T

## Mean:
Table.D3[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.D3[i1+1:4, 2] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D3[i1+1:4, 3] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D3[i1+6:9, 1] <- round(colMeans(p.MAP), 3)    # Est
Table.D3[i1+6:9, 2] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D3[i1+6:9, 3] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D4[1:8, 1] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D4[1:8, 2] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D4[1:8, 3] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D4[10:17, 1] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D4[10:17, 2] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D4[10:17, 3] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D5[1:8, 1] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D5[1:8, 2] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D5[1:8, 3] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D5[10:17, 1] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D5[10:17, 2] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D5[10:17, 3] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D3[i1+11, 1] <- round( mean(T), 1 )    
Table.D3[i1+12, 1] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
delta.Mean <- res_h3$delta.Mean
delta.SE <- res_h3$delta.SE
p.MAP <- res_h3$p.MAP
delta.MAP <- res_h3$delta.MAP
T <- res_h3$T

## Mean:
Table.D3[i1+1:4, 5] <- round(colMeans(p.Mean), 3)   # Est
Table.D3[i1+1:4, 6] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D3[i1+1:4, 7] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D3[i1+6:9, 5] <- round(colMeans(p.MAP), 3)    # Est
Table.D3[i1+6:9, 6] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D3[i1+6:9, 7] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D4[1:8, 5] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D4[1:8, 6] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D4[1:8, 7] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D4[10:17, 5] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D4[10:17, 6] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D4[10:17, 7] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D5[1:8, 5] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D5[1:8, 6] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D5[1:8, 7] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D5[10:17, 5] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D5[10:17, 6] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D5[10:17, 7] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D3[i1+11, 5] <- round( mean(T), 1 )    
Table.D3[i1+12, 5] <- round( sd(T), 1 )


## H4
Protocol <- "H4"
res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h4$p.Mean
p.SE <- res_h4$p.SE
delta.Mean <- res_h4$delta.Mean
delta.SE <- res_h4$delta.SE
p.MAP <- res_h4$p.MAP
delta.MAP <- res_h4$delta.MAP
T <- res_h4$T

## Mean:
Table.D3[i1+1:4, 9] <- round(colMeans(p.Mean), 3)   # Est
Table.D3[i1+1:4, 10] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D3[i1+1:4, 11] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D3[i1+6:9, 9] <- round(colMeans(p.MAP), 3)    # Est
Table.D3[i1+6:9, 10] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D3[i1+6:9, 11] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D4[1:8, 9] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D4[1:8, 10] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D4[1:8, 11] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D4[10:17, 9] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D4[10:17, 10] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D4[10:17, 11] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D5[1:8, 9] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D5[1:8, 10] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D5[1:8, 11] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D5[10:17, 9] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D5[10:17, 10] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D5[10:17, 11] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D3[i1+11, 9] <- round( mean(T), 1 )    
Table.D3[i1+12, 9] <- round( sd(T), 1 )


## AT
Protocol <- "AT"
res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
delta.Mean <- res_at$delta.Mean
delta.SE <- res_at$delta.SE
p.MAP <- res_at$p.MAP
delta.MAP <- res_at$delta.MAP
T <- res_at$T

## Mean:
Table.D3[i1+1:4, 13] <- round(colMeans(p.Mean), 3)   # Est
Table.D3[i1+1:4, 14] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D3[i1+1:4, 15] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D3[i1+6:9, 13] <- round(colMeans(p.MAP), 3)    # Est
Table.D3[i1+6:9, 14] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D3[i1+6:9, 15] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D4[1:8, 13] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D4[1:8, 14] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D4[1:8, 15] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D4[10:17, 13] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D4[10:17, 14] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D4[10:17, 15] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D5[1:8, 13] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D5[1:8, 14] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D5[1:8, 15] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D5[10:17, 13] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D5[10:17, 14] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D5[10:17, 15] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D3[i1+11, 13] <- round( mean(T), 1 )    
Table.D3[i1+12, 13] <- round( sd(T), 1 )
}

## Preparing Table D.3
dfr1 <- data.frame( cbind(
     c("","","","","","Config-I","","","","","","", 
	   "",  "","","","","","Config-II","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.990", "p10=0.004", "p01=0.004", "p11=0.002", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.D3 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_D3 <- as.data.frame(dfr1)
colnames( Table_D3 ) <- c("", "", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")				   


##============= Table D.3 =============##

protocols <- paste("                                   H2                    H3                    H4                   AT")
cline <-     paste("                          ===================   ===================   ===================   ====================")

noquote(protocols); noquote(cline); Table_D3


## Preparing Tables D.4 & D.5

dfr2 <- data.frame( cbind(
     c("", "", "", "", "Se:(1)1=0.95", "Se:(1)2=0.95", "Sp:(1)1=0.98", "Sp:(1)2=0.98",
       "Se:(2)1=0.98", "Se:(2)2=0.98", "Sp:(2)1=0.99", "Sp:(2)2=0.99", "", "", "", "", ""),
     c("", "", "", "Mean", "", "", "", "", "", "", "", "", "", "MAP", "", "", "")))

dfr3 <- data.frame( dfr2, Table.D4 )
dfr3 <- sapply(dfr3, as.character)
dfr3[is.na(dfr3)] <- " "

Table_D4 <- as.data.frame(dfr3)
colnames( Table_D4 ) <- c("", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")
						   

##============= Table D.4 =============##

protocols <- paste("                         H2                  H3                 H4                  AT")
cline <-     paste("                 =================   =================   =================   =================")

noquote(protocols); noquote(cline); Table_D4


dfr4 <- data.frame( dfr2, Table.D5 )
dfr4 <- sapply(dfr4, as.character)
dfr4[is.na(dfr4)] <- " "

Table_D5 <- as.data.frame(dfr4)
colnames( Table_D5 ) <- c("", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")
						   

##============= Table D.5 =============##

protocols <- paste("                         H2                  H3                 H4                  AT")
cline <-     paste("                 =================   =================   =================   =================")

noquote(protocols); noquote(cline); Table_D5


###########################################

## Reproducing Tables D.6-D.8

Table <- "D6_D8"
Table.D6 <- matrix(NA, nrow = 25, ncol = 15)
Table.D7 <- matrix(NA, nrow = 17, ncol = 15)
Table.D8 <- matrix(NA, nrow = 17, ncol = 15)

for(Configuration in c("I", "II")){

if(Configuration == "I"){
  i1 <- 0
  i2 <- 0
}

if(Configuration == "II"){
  i1 <- 13
  i2 <- 10
}


## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
delta.Mean <- res_h2$delta.Mean
delta.SE <- res_h2$delta.SE
p.MAP <- res_h2$p.MAP
delta.MAP <- res_h2$delta.MAP
T <- res_h2$T

## Mean:
Table.D6[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.D6[i1+1:4, 2] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D6[i1+1:4, 3] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D6[i1+6:9, 1] <- round(colMeans(p.MAP), 3)    # Est
Table.D6[i1+6:9, 2] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D6[i1+6:9, 3] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D7[1:8, 1] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D7[1:8, 2] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D7[1:8, 3] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D7[10:17, 1] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D7[10:17, 2] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D7[10:17, 3] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D8[1:8, 1] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D8[1:8, 2] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D8[1:8, 3] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D8[10:17, 1] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D8[10:17, 2] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D8[10:17, 3] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D6[i1+11, 1] <- round( mean(T), 1 )    
Table.D6[i1+12, 1] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
delta.Mean <- res_h3$delta.Mean
delta.SE <- res_h3$delta.SE
p.MAP <- res_h3$p.MAP
delta.MAP <- res_h3$delta.MAP
T <- res_h3$T

## Mean:
Table.D6[i1+1:4, 5] <- round(colMeans(p.Mean), 3)   # Est
Table.D6[i1+1:4, 6] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D6[i1+1:4, 7] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D6[i1+6:9, 5] <- round(colMeans(p.MAP), 3)    # Est
Table.D6[i1+6:9, 6] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D6[i1+6:9, 7] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D7[1:8, 5] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D7[1:8, 6] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D7[1:8, 7] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D7[10:17, 5] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D7[10:17, 6] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D7[10:17, 7] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D8[1:8, 5] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D8[1:8, 6] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D8[1:8, 7] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D8[10:17, 5] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D8[10:17, 6] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D8[10:17, 7] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D6[i1+11, 5] <- round( mean(T), 1 )    
Table.D6[i1+12, 5] <- round( sd(T), 1 )


## H4
Protocol <- "H4"
res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h4$p.Mean
p.SE <- res_h4$p.SE
delta.Mean <- res_h4$delta.Mean
delta.SE <- res_h4$delta.SE
p.MAP <- res_h4$p.MAP
delta.MAP <- res_h4$delta.MAP
T <- res_h4$T

## Mean:
Table.D6[i1+1:4, 9] <- round(colMeans(p.Mean), 3)   # Est
Table.D6[i1+1:4, 10] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D6[i1+1:4, 11] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D6[i1+6:9, 9] <- round(colMeans(p.MAP), 3)    # Est
Table.D6[i1+6:9, 10] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D6[i1+6:9, 11] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D7[1:8, 9] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D7[1:8, 10] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D7[1:8, 11] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D7[10:17, 9] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D7[10:17, 10] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D7[10:17, 11] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D8[1:8, 9] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D8[1:8, 10] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D8[1:8, 11] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D8[10:17, 9] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D8[10:17, 10] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D8[10:17, 11] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D6[i1+11, 9] <- round( mean(T), 1 )    
Table.D6[i1+12, 9] <- round( sd(T), 1 )


## AT
Protocol <- "AT"
res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Configuration, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
delta.Mean <- res_at$delta.Mean
delta.SE <- res_at$delta.SE
p.MAP <- res_at$p.MAP
delta.MAP <- res_at$delta.MAP
T <- res_at$T

## Mean:
Table.D6[i1+1:4, 13] <- round(colMeans(p.Mean), 3)   # Est
Table.D6[i1+1:4, 14] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D6[i1+1:4, 15] <- round(colMeans(p.SE), 4)     # SE

## MAP:
Table.D6[i1+6:9, 13] <- round(colMeans(p.MAP), 3)    # Est
Table.D6[i1+6:9, 14] <- round(apply(p.MAP,2,sd), 4)  # SD
Table.D6[i1+6:9, 15] <- round(colMeans(p.SE), 4)     # SE

if( Configuration == "I" ){
  # Mean
  Table.D7[1:8, 13] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D7[1:8, 14] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D7[1:8, 15] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D7[10:17, 13] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D7[10:17, 14] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D7[10:17, 15] <- round(colMeans(delta.SE), 3)     # SE
}

if(Configuration == "II"){
  # Mean
  Table.D8[1:8, 13] <- round(colMeans(delta.Mean), 3)   # Est
  Table.D8[1:8, 14] <- round(apply(delta.Mean,2,sd), 3) # SD
  Table.D8[1:8, 15] <- round(colMeans(delta.SE), 3)     # SE

  # MAP
  Table.D8[10:17, 13] <- round(colMeans(delta.MAP), 3)    # Est
  Table.D8[10:17, 14] <- round(apply(delta.MAP,2,sd), 3)  # SD
  Table.D8[10:17, 15] <- round(colMeans(delta.SE), 3)     # SE
}

## Avg. number of tests:
Table.D6[i1+11, 13] <- round( mean(T), 1 )    
Table.D6[i1+12, 13] <- round( sd(T), 1 )
}

## Preparing Table D.6
dfr1 <- data.frame( cbind(
     c("","","","","","Config-I","","","","","","", 
	   "",  "","","","","","Config-II","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.990", "p10=0.004", "p01=0.004", "p11=0.002", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.D6 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_D6 <- as.data.frame(dfr1)
colnames( Table_D6 ) <- c("", "", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")				   


##============= Table D.6 =============##

protocols <- paste("                                   H2                    H3                    H4                   AT")
cline <-     paste("                          ===================   ===================   ===================   ====================")

noquote(protocols); noquote(cline); Table_D6


## Preparing Table D.7 & D.8
dfr2 <- data.frame( cbind(
     c("", "", "", "", "Se:(1)1=0.95", "Se:(1)2=0.95", "Sp:(1)1=0.98", "Sp:(1)2=0.98",
       "Se:(2)1=0.98", "Se:(2)2=0.98", "Sp:(2)1=0.99", "Sp:(2)2=0.99", "", "", "", "", ""),
     c("", "", "", "Mean", "", "", "", "", "", "", "", "", "", "MAP", "", "", "")))

dfr3 <- data.frame( dfr2, Table.D7 )
dfr3 <- sapply(dfr3, as.character)
dfr3[is.na(dfr3)] <- " "

Table_D7 <- as.data.frame(dfr3)
colnames( Table_D7 ) <- c("", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")


##============= Table D.7 =============##

protocols <- paste("                         H2                  H3                 H4                  AT")
cline <-     paste("                 =================   =================   =================   =================")

noquote(protocols); noquote(cline); Table_D7


dfr4 <- data.frame( dfr2, Table.D8 )
dfr4 <- sapply(dfr4, as.character)
dfr4[is.na(dfr4)] <- " "

Table_D8 <- as.data.frame(dfr4)
colnames( Table_D8 ) <- c("", "", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")
						   

##============= Table D.8 =============##

protocols <- paste("                         H2                  H3                 H4                  AT")
cline <-     paste("                 =================   =================   =================   =================")

noquote(protocols); noquote(cline); Table_D8


###########################################

## Reproducing Table D.9

Table <- "D9"
Table.D9 <- matrix(NA, nrow = 25, ncol = 19)

for(Accuracy in c("high", "low")){
  if(Accuracy == "high"){
    i1 <- 0
    i2 <- 0
  }
  if(Accuracy == "low"){
    i1 <- 13
    i2 <- 10
  }

## MPT
Protocol <- "MPT"
res_mpt <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_mpt$p.Mean
p.SE <- res_mpt$p.SE
p.MAP <- res_mpt$p.MAP
T <- res_mpt$T

## Mean Estimation:
Table.D9[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.D9[i1+1:4, 2] <- round(apply(p.Mean,2,sd), 4) # SD
Table.D9[i1+1:4, 3] <- round(colMeans(p.SE), 4)     # SE

## MAP Estimation:
Table.D9[i1+6:9, 1] <- round(colMeans(p.MAP), 3)    # Est
Table.D9[i1+6:9, 2] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D9[i1+6:9, 3] <- round(colMeans(p.SE), 4)     # SE

## Avg. number of tests:
Table.D9[i1+11, 2] <- round( mean(T), 1 )    
Table.D9[i1+12, 2] <- round( sd(T), 1 )

## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
p.MAP <- res_h2$p.MAP
T <- res_h2$T

## Mean Estimation:
Table.D9[i1+1:4, 5] <- round(colMeans(p.Mean), 3)     # Est
Table.D9[i1+1:4, 6] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D9[i1+1:4, 7] <- round(colMeans(p.SE), 4)       # SE

## MAP Estimation:
Table.D9[i1+6:9, 5] <- round(colMeans(p.MAP),  3)     # Est
Table.D9[i1+6:9, 6] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D9[i1+6:9, 7] <- round(colMeans(p.SE), 4)       # SE

## Avg. number of tests:
Table.D9[i1+11, 6] <- round( mean(T), 1 )    
Table.D9[i1+12, 6] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
p.MAP <- res_h3$p.MAP
T <- res_h3$T

## Mean Estimation:
Table.D9[i1+1:4, 9] <- round(colMeans(p.Mean), 3)   # Est
Table.D9[i1+1:4, 10] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D9[i1+1:4, 11] <- round(colMeans(p.SE), 4)     # SE

## MAP Estimation:
Table.D9[i1+6:9, 9] <- round(colMeans(p.MAP), 3)    # Est
Table.D9[i1+6:9, 10] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D9[i1+6:9, 11] <- round(colMeans(p.SE), 4)     # SE

## Avg. number of tests:
Table.D9[i1+11, 10] <- round( mean(T), 1 )    
Table.D9[i1+12, 10] <- round( sd(T), 1 )


## H4
Protocol <- "H4"
res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h4$p.Mean
p.SE <- res_h4$p.SE
p.MAP <- res_h4$p.MAP
T <- res_h4$T

## Mean Estimation:
Table.D9[i1+1:4, 13] <- round(colMeans(p.Mean), 3)     # Est
Table.D9[i1+1:4, 14] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D9[i1+1:4, 15] <- round(colMeans(p.SE), 4)       # SE

## MAP Estimation:
Table.D9[i1+6:9, 13] <- round(colMeans(p.MAP),   3)    # Est
Table.D9[i1+6:9, 14] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D9[i1+6:9, 15] <- round(colMeans(p.SE), 4)       # SE

## Avg. number of tests:
Table.D9[i1+11, 14] <- round( mean(T), 1 )    
Table.D9[i1+12, 14] <- round( sd(T), 1 )


## AT
Protocol <- "AT"
res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
p.MAP <- res_at$p.MAP
T <- res_at$T

## Mean Estimation:
Table.D9[i1+1:4, 17] <- round(colMeans(p.Mean), 3)   # Est
Table.D9[i1+1:4, 18] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D9[i1+1:4, 19] <- round(colMeans(p.SE), 4)     # SE

## MAP Estimation:
Table.D9[i1+6:9, 17] <- round(colMeans(p.MAP), 3)      # Est
Table.D9[i1+6:9, 18] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D9[i1+6:9, 19] <- round(colMeans(p.SE), 4)       # SE

## Avg. number of tests:
Table.D9[i1+11, 18] <- round( mean(T), 1 )    
Table.D9[i1+12, 18] <- round( sd(T), 1 )
}

## Preparing & saving Table D.9
dfr1 <- data.frame( cbind(
     c("","","","","","High accuracy","","","","","","", 
	   "",  "","","","","","Low accuracy","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.D9 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_D9 <- as.data.frame(dfr1)
colnames( Table_D9 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                        "", "Est", "SD", "SE", "", "Est", "SD", "SE", "", "Est", "SD", "SE")

##============= Table D.9 =============##

protocols <- paste("                                    MPT                     H2                    H3                    H4                    AT")
cline <-     paste("                            ===================    ===================   ===================   ===================   ====================")

noquote(protocols); noquote(cline); Table_D9


###########################################

## Reproducing Tables D.10-D.11

Table <- "D10_D11"
Table.D10 <- matrix(NA, nrow = 25, ncol = 15)
Table.D11 <- matrix(NA, nrow = 19, ncol = 15)

for(Accuracy in c("high", "low")){

if(Accuracy == "high"){
  Se <- c(.95, .95)  # True assay sensitivities
  Sp <- c(.99, .99)  # True assay specificities
  i1 <- 0
  i2 <- 0
}

if(Accuracy == "low"){
  Se <- c(.85, .85)  # True assay sensitivities
  Sp <- c(.90, .90)  # True assay specificities
  i1 <- 13
  i2 <- 10
}

## H2
Protocol <- "H2"
res_h2 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h2$p.Mean
p.SE <- res_h2$p.SE
delta.Mean <- res_h2$delta.Mean
delta.SE <- res_h2$delta.SE
p.MAP <- res_h2$p.MAP
delta.MAP <- res_h2$delta.MAP
T <- res_h2$T
			 
## Mean Estimation:
Table.D10[i1+1:4, 1] <- round(colMeans(p.Mean), 3)   # Est
Table.D10[i1+1:4, 2] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D10[i1+1:4, 3] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+1:4, 1] <- round(colMeans(delta.Mean),3)   # Est
Table.D11[i2+1:4, 2] <- round(apply(delta.Mean,2,sd),3) # SD
Table.D11[i2+1:4, 3] <- round(colMeans(delta.SE),3)     # SE

## MAP Estimation:
Table.D10[i1+6:9, 1] <- round(colMeans(p.MAP),3)    # Est
Table.D10[i1+6:9, 2] <- round(apply(p.MAP,2,sd),4)  # SD
Table.D10[i1+6:9, 3] <- round(colMeans(p.SE),4)     # SE

Table.D11[i2+6:9, 1] <- round(colMeans(delta.MAP),3)    # Est
Table.D11[i2+6:9, 2] <- round(apply(delta.MAP,2,sd),3)  # SD
Table.D11[i2+6:9, 3] <- round(colMeans(delta.SE),3)     # SE

## Avg. number of tests:
Table.D10[i1+11, 2] <- round( mean(T), 1 )    
Table.D10[i1+12, 2] <- round( sd(T), 1 )


## H3
Protocol <- "H3"
res_h3 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h3$p.Mean
p.SE <- res_h3$p.SE
delta.Mean <- res_h3$delta.Mean
delta.SE <- res_h3$delta.SE
p.MAP <- res_h3$p.MAP
delta.MAP <- res_h3$delta.MAP
T <- res_h3$T

## Mean Estimation:
Table.D10[i1+1:4, 5] <- round(colMeans(p.Mean), 3)   # Est
Table.D10[i1+1:4, 6] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D10[i1+1:4, 7] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+1:4, 5] <- round(colMeans(delta.Mean), 3)   # Est
Table.D11[i2+1:4, 6] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.D11[i2+1:4, 7] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.D10[i1+6:9, 5] <- round(colMeans(p.MAP), 3)    # Est
Table.D10[i1+6:9, 6] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D10[i1+6:9, 7] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+6:9, 5] <- round(colMeans(delta.MAP), 3)    # Est
Table.D11[i2+6:9, 6] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.D11[i2+6:9, 7] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.D10[i1+11, 6] <- round( mean(T), 1 )    
Table.D10[i1+12, 6] <- round( sd(T), 1 )


## H4
Protocol <- "H4"
res_h4 <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_h4$p.Mean
p.SE <- res_h4$p.SE
delta.Mean <- res_h4$delta.Mean
delta.SE <- res_h4$delta.SE
p.MAP <- res_h4$p.MAP
delta.MAP <- res_h4$delta.MAP
T <- res_h4$T

## Mean Estimation:
Table.D10[i1+1:4, 9] <- round(colMeans(p.Mean), 3)   # Est
Table.D10[i1+1:4, 10] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D10[i1+1:4, 11] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+1:4, 9] <- round(colMeans(delta.Mean), 3)   # Est
Table.D11[i2+1:4, 10] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.D11[i2+1:4, 11] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.D10[i1+6:9, 9] <- round(colMeans(p.MAP), 3)    # Est
Table.D10[i1+6:9, 10] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D10[i1+6:9, 11] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+6:9, 9] <- round(colMeans(delta.MAP), 3)    # Est
Table.D11[i2+6:9, 10] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.D11[i2+6:9, 11] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.D10[i1+11, 10] <- round( mean(T), 1 )    
Table.D10[i1+12, 10] <- round( sd(T), 1 )

## AT
Protocol <- "AT"
res_at <- readRDS( paste("./simulation/intermediate_results/", "Table_", Table, "_config-", Accuracy, "_protocol-", Protocol, ".rds", sep="") )

p.Mean <- res_at$p.Mean
p.SE <- res_at$p.SE
delta.Mean <- res_at$delta.Mean
delta.SE <- res_at$delta.SE
p.MAP <- res_at$p.MAP
delta.MAP <- res_at$delta.MAP
T <- res_at$T

## Mean Estimation:
Table.D10[i1+1:4, 13] <- round(colMeans(p.Mean), 3)   # Est
Table.D10[i1+1:4, 14] <- round(apply(p.Mean, 2, sd), 4) # SD
Table.D10[i1+1:4, 15] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+1:4, 13] <- round(colMeans(delta.Mean), 3)   # Est
Table.D11[i2+1:4, 14] <- round(apply(delta.Mean, 2, sd), 3) # SD
Table.D11[i2+1:4, 15] <- round(colMeans(delta.SE), 3)     # SE

## MAP Estimation:
Table.D10[i1+6:9, 13] <- round(colMeans(p.MAP), 3)    # Est
Table.D10[i1+6:9, 14] <- round(apply(p.MAP, 2, sd), 4)  # SD
Table.D10[i1+6:9, 15] <- round(colMeans(p.SE), 4)     # SE

Table.D11[i2+6:9, 13] <- round(colMeans(delta.MAP), 3)    # Est
Table.D11[i2+6:9, 14] <- round(apply(delta.MAP, 2, sd), 3)  # SD
Table.D11[i2+6:9, 15] <- round(colMeans(delta.SE), 3)     # SE

## Avg. number of tests:
Table.D10[i1+11, 14] <- round( mean(T), 1 )    
Table.D10[i1+12, 14] <- round( sd(T), 1 )
}

## Preparing & saving Table D.10
dfr1 <- data.frame( cbind(
     c("","","","","","High accuracy","","","","","","", 
	   "",  "","","","","","Low accuracy","","","","","",""),
     c("", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", "", "", 
	   "", "", "", "p00=0.95", "p10=0.02", "p01=0.02", "p11=0.01", "", "", "", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T", "", 
	   "Mean", "", "", "", "", "MAP", "", "", "", "", "T.bar", "S.T")))

dfr1 <- data.frame( dfr1, Table.D10 )
dfr1 <- sapply(dfr1, as.character)
dfr1[is.na(dfr1)] <- " "
Table_D10 <- as.data.frame(dfr1)
colnames( Table_D10 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")				   


## Preparing & saving Table D.11
dfr2 <- data.frame( cbind(
     c("","","","","","High accuracy","","","","","","", 
	   "","","","Low accuracy","","",""),
     c("", "", "", "Se:(1)1=0.95", "Se:(1)2=0.95", "Sp:(1)1=0.99", "Sp:(1)2=0.99", "", "", "",  
	   "", "", "", "Se:(1)1=0.85", "Se:(1)2=0.85", "Sp:(1)1=0.90", "Sp:(1)2=0.90", "", ""),  
     c("Mean", "", "", "", "", "MAP", "", "", "", "",  
	   "Mean", "", "", "", "", "MAP", "", "", "")))

dfr2 <- data.frame( dfr2, Table.D11 )
dfr2 <- sapply(dfr2, as.character)
dfr2[is.na(dfr2)] <- " "

Table_D11 <- as.data.frame(dfr2)
colnames( Table_D11 ) <- c("", "","", "Est", "SD", "SE", "", "Est", "SD", "SE", 
                           "", "Est", "SD", "SE", "", "Est", "SD", "SE")
						   

##============= Table D.10 =============##

protocols <- paste("                                     H2                    H3                    H4                   AT")
cline <-     paste("                            ===================   ===================   ===================   ====================")

noquote(protocols); noquote(cline); Table_D10


##============= Table D.11 =============##

protocols <- paste("                                       H2                  H3                 H4                  AT")
cline <-     paste("                               =================   =================   =================   =================")

noquote(protocols); noquote(cline); Table_D11


