
Supplementary information / reproducible research files for the manuscript entitled, 
"Estimating the prevalence of two or more diseases using outcomes from multiplex group testing."

Authors: Md S. Warasi, Joshua M. Tebbs, Christopher S. McMahan, and Christopher R. Bilder

Code was written by Md S. Warasi. In case of questions or comments, 
please contact Md S. Warasi at msarker@radford.edu or Joshua M. Tebbs at tebbs@stat.sc.edu

The code was written and evaluated in R with the following software version:

R version 4.2.2 (2022-10-31 ucrt)
Platform: x86_64-w64-mingw32/x64 (64-bit)
Running under: Windows 10 x64 (build 22621)

Matrix products: default

Random number generation:
 RNG:     L'Ecuyer-CMRG 
 Normal:  Inversion 
 Sample:  Rejection 
 
locale:
[1] LC_COLLATE=English_United States.utf8  LC_CTYPE=English_United States.utf8   
[3] LC_MONETARY=English_United States.utf8 LC_NUMERIC=C                          
[5] LC_TIME=English_United States.utf8    

attached base packages:
[1] parallel  stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] binGroup2_1.2.4          RcppArmadillo_0.11.4.3.1 Rcpp_1.0.10              MCMCpack_1.6-3          
[5] MASS_7.3-58.1            coda_0.19-4             

loaded via a namespace (and not attached):
 [1] gmp_0.6-10         compiler_4.2.2     pillar_1.8.1       mathjaxr_1.6-0     tools_4.2.2       
 [6] partitions_1.10-7  lifecycle_1.0.3    tibble_3.1.8       gtable_0.3.1       lattice_0.20-45   
[11] pkgconfig_2.0.3    rlang_1.0.6        Matrix_1.5-1       cli_3.6.0          SparseM_1.81      
[16] polynom_1.4-1      vctrs_0.5.2        MatrixModels_0.5-1 grid_4.2.2         glue_1.6.2        
[21] R6_2.5.1           fansi_1.0.4        Rdpack_2.4         survival_3.4-0     ggplot2_3.4.0     
[26] magrittr_2.0.3     scales_1.2.1       mcmc_0.9-7         rbibutils_2.2.13   splines_4.2.2     
[31] colorspace_2.1-0   quantreg_5.94      utf8_1.2.2         rBeta2009_1.0      munsell_0.5.0     


Note:
----
1. The code was executed in a Windows computer using 10 parallel cores.
   We used the "parallel" package for creating the clusters. The argument 
   "ncores" is used to specify the number of cores to be used.  

2. The argument "nsims" is used to specify the number of simlated data sets.
   Throughout the article, we used nsims = 500 data sets. Because our estimation 
   techniques involve multiple Gibbs samplers, the computing time can be quite long. 
   To reduce the time, one can use a smaller value for nsims. 
   The saved intermediate results are based on nsims = 10 data sets. 

3. When ncores = 10 and nsims = 500, our code will reproduce the manuscript results. 
   Otherwise, results produced by our code can be somewhat different.
 
   When ncores = 10 and nsims = 10, the code will reproduce the saved intermediate results.
   Otherwise, the results can be somewhat different.

 
This folder contains code and data that can be used to reproduce 
all results (tables) presented in the article. The folder consists 
of three subfolders.

./source_code/
  All source code is provided in this subfolder.

  MainFunctions.R contains two main R functions mult.gt.bayes() and mult.gt.bayes_L2() 
  that can be used to implement the proposed estimation techniques with L = 1  
  assay and L = 2 assays, respectively. Both functions have been documented.

  SupportPrograms.R provides supporting functions.
  
  GT_sim_fns.R contains R functions that can simulate multiplex group testing
  data for multistage hierarchical protocols and array testing protocols.
  
  The dll files gbbstwodisgen.dll, mapacrtwodgen.dll, and ytiltwodbayes.dll
  contain FORTRAN programs. These programs execute the Gibbs samplers used 
  in the posterior sampling and EM algorithm. For efficient computing, the Gibbs 
  samplers have been written in FORTRAN and called into R using .C() function.
  
  Hierarchical.cpp contains C++ programs, which are used for optimal pool size 
  calculation by minimizing the expected number of tests.
  
  The csv files - psz_s2.csv, psz_s2.csv, psz_s2.csv, psz_s2.csv, psz_s2.csv - consists 
  of all possible combinations of pool sizes. The optimal pool size is determined from 
  these combinations based on a numerical search.

./simulation/
  This folder contains four R scripts that can be used to reproduce 
  the tables of simulation result (Section 5). The scripts 
  are separated based on the functionality of the code.

  code_Tables_1-3.R can reproduce Tables 1-3 in the article. 
  
  The other four code scripts reproduce Tables D.1-D.11 in Appendix D.
  
  result_Tables_1-3.R and result_Appendix_Tables_D1-D11.R can display the tables
  exactly as shown in the manuscript. 
   
  ./intermediate_results/
     Intermediate results from the first 10 simulated data sets are saved in this folder.
     That is, when nsims = 10 and ncores = 10, the results produced by our code will be 
     identical to the outputs saved in this "intermediate_results" folder.

./data_analysis/
  This folder consists of three R scripts that can be used to reproduce 
  the chlamydia and gonorrhea data analysis results presented in Tables 4 - 6 (Section 6).

   code_Iowa_data_sim.R can simulate individual testing data comparable to the one
   we have from Iowa. Note that we use individual case identification results from Iowa and 
   then simulate group testing data under different pooling protocols; see Section 6.
   
   code_Tables_4-6 can reproduce Tables 4-6 in the article.
   
   result_Tables_4-6 can display Tables 4-6 using outputs from the "intermidiate-results" folder.

  ./Iowa_data/
     This folder contains two simulated data sets which are comparable to the real data set
     obtained from Iowa. The data sets are created using the R script code_Iowa_data_sim.R. 

  ./intermediate_results/
     Intermediate results from the first 10 simulated data sets are saved in this folder.
     That is, when nsims = 10 and ncores = 10, the results produced by our code will be 
     identical to the outputs saved in this "intermediate_results" folder.	 
	 
